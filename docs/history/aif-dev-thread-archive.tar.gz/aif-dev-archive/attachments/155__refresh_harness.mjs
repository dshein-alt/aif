/* Execute the script /ui actually ships, against a stubbed DOM, and ask what a reader experiences. */
import fs from 'node:fs';

const IV = 90000;
const src = fs.readFileSync('/tmp/refresh.js', 'utf8');

// One page view. The store is shared between views, the way sessionStorage is across reloads.
function view(store, { scrollY, innerHeight, scrollHeight, hiddenSince, now = 0 }) {
  const ev = {};
  let sy = scrollY, restored = null, reloaded = 0;
  globalThis.sessionStorage = {
    setItem: (k, v) => store.set(k, String(v)),
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    removeItem: (k) => store.delete(k),
  };
  globalThis.document = { hidden: false, documentElement: { scrollHeight }, addEventListener: (t, f) => { ev[t] = f; } };
  globalThis.addEventListener = (t, f) => { ev[t] = f; };
  Object.defineProperty(globalThis, 'innerHeight', { value: innerHeight, configurable: true });
  Object.defineProperty(globalThis, 'scrollY', { get: () => sy, configurable: true });
  globalThis.scrollTo = (_x, y) => { sy = y; restored = y; };
  globalThis.location = { pathname: '/ui/thread/3', search: '', reload: () => { reloaded++; } };
  let tick = null;
  globalThis.setInterval = (f) => { tick = f; return 1; };
  const realNow = Date.now;
  Date.now = () => realNow() + now;
  try {
    new Function(src)();
    ev.load();                                   // this view finishes loading
    return {
      restored: () => restored,
      reloaded: () => reloaded,
      hide: () => { sy = scrollY; ev.pagehide(); return [...store.values()].pop(); },
      visibleAfter: (ms) => { Date.now = () => realNow() + ms; document.hidden = false; ev.visibilitychange(); },
      wentHidden: () => { document.hidden = true; ev.visibilitychange(); },
      tick: () => tick(),
    };
  } finally {
    /* Date.now is restored by the caller that needs time travel next */
    globalThis.__restoreNow = () => { Date.now = realNow; };
  }
}

const results = [];
function check(label, ok, detail) { results.push(`${ok ? 'PASS' : 'FAIL'}  ${label}${detail ? '  ' + detail : ''}`); }

// A reload while the reader sits at the bottom of a growing thread: they must end up at the bottom.
{
  const store = new Map();
  const a = view(store, { scrollY: 900, innerHeight: 800, scrollHeight: 1700 });
  const saved = a.hide();                                   // reader at the bottom -> marker, not pixels
  const b = view(store, { scrollY: 0, innerHeight: 800, scrollHeight: 2600 }); // thread grew by 900px
  check('bottom sticks to bottom', saved === 'bottom' && b.restored() === 2600, `saved=${saved} restored=${b.restored()}`);
}

// A reload while the reader is mid-thread: the exact offset comes back, new posts stay below.
{
  const store = new Map();
  const a = view(store, { scrollY: 200, innerHeight: 800, scrollHeight: 5000 });
  const saved = a.hide();
  const b = view(store, { scrollY: 0, innerHeight: 800, scrollHeight: 5900 });
  check('middle keeps its offset', saved === '200' && b.restored() === 200, `saved=${saved} restored=${b.restored()}`);
  check('restoring clears the marker', !store.size);
}

// A tab hidden longer than the interval reloads as soon as it is looked at again.
{
  const store = new Map();
  const a = view(store, { scrollY: 900, innerHeight: 800, scrollHeight: 1700 });
  a.wentHidden();
  a.visibleAfter(IV + 1000);
  check('long absence catches up', a.reloaded() === 1, `reloaded=${a.reloaded()}`);
}

// A tab hidden only briefly does not reload twice for nothing.
{
  const store = new Map();
  const a = view(store, { scrollY: 900, innerHeight: 800, scrollHeight: 1700 });
  a.wentHidden();
  a.visibleAfter(2000);
  check('brief absence stays put', a.reloaded() === 0, `reloaded=${a.reloaded()}`);
}

// The ordinary visible tick still reloads, which is the whole feature.
{
  const store = new Map();
  const a = view(store, { scrollY: 0, innerHeight: 800, scrollHeight: 1700 });
  a.tick();
  check('visible tick reloads', a.reloaded() === 1);
}

console.log(results.join('\n'));
process.exit(results.some((r) => r.startsWith('FAIL')) ? 1 : 0);
