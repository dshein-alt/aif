#!/usr/bin/env python3
"""Read-only AIF surface-parity probe: skill card <-> MCP tools/list <-> REST error shape.

    AIF_TOKEN=... python3 parity.py [base_url]

Stdlib only. Makes no state-changing calls (skill, tools/list, and one deliberately
bad-argument poll). Run it at any commit: it is meant to be re-runnable evidence, not
a one-off.
"""
import json
import os
import re
import sys
import urllib.error
import urllib.request

BASE = (sys.argv[1] if len(sys.argv) > 1 else os.environ.get("AIF_BASE", "http://127.0.0.1:18080")).rstrip("/")
TOK = os.environ.get("AIF_TOKEN") or open(os.path.expanduser("~/.aif_token")).read().strip()


def call(path, body=None):
    req = urllib.request.Request(
        BASE + path,
        data=json.dumps(body).encode() if body else None,
        headers={"Authorization": "Bearer " + TOK, "Content-Type": "application/json"},
    )
    try:
        return urllib.request.urlopen(req, timeout=20).read().decode()
    except urllib.error.HTTPError as e:
        return "HTTP %s %s" % (e.code, e.read().decode(errors="replace"))


# 1. op sets: skill card's OPS block vs MCP tools/list
card = call("/api/skill")
ops_block = card.split("3 OPS")[1].split("4 REST PATHS")[0]
card_ops = set(re.findall(r"([a-z_]{2,})\s*\{", ops_block)) - {"op"}  # "op" is the generic POST /api/op
mcp_ops = {t["name"] for t in json.loads(call("/mcp", {"jsonrpc": "2.0", "id": 1, "method": "tools/list"}))["result"]["tools"]}

print("card ops  (%2d): %s" % (len(card_ops), sorted(card_ops)))
print("mcp ops   (%2d): %s" % (len(mcp_ops), sorted(mcp_ops)))
print("card-only : %s" % sorted(card_ops - mcp_ops))
print("mcp-only  : %s" % sorted(mcp_ops - card_ops))

# 2. error parity: the same rejected call must carry the same text on both transports
rest = call("/api/op?do=poll&wait=1")
mcp = json.loads(call("/mcp", {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                               "params": {"name": "poll", "arguments": {"wait": 1}}}))
rest_err = json.loads(rest.split(" ", 2)[2])
mcp_err = json.loads(mcp["result"]["content"][0]["text"])
print("error parity (poll wait=1): %s" % ("identical" if rest_err == mcp_err else "DIVERGES"))
print("  rest: %s" % rest)
print("  mcp : %s" % json.dumps(mcp_err))

ok = not (card_ops - mcp_ops) and not (mcp_ops - card_ops) and rest_err == mcp_err
print("RESULT: %s" % ("PASS" if ok else "MISMATCH — see sets above"))
sys.exit(0 if ok else 1)
